/**************************************************************************************************
Nom du fichier : IntDetecteurDeLigne.h
Auteur : Naomie Dion
Date de création : 27 Novembre 2024
Version 1.1    
***************************************************************************************************/

#ifndef INTDETECTEURDELIGNE_H
#define INTDETECTEURDELIGNE_H

// *************************************************************************************************
//  INCLUDES
// *************************************************************************************************
#include "PiloteI2C.h"

// *************************************************************************************************
//  LES PROTOTYPES DES FONCTIONS
// *************************************************************************************************
class CPcf 
{
public:
    CPcf(unsigned char adresseI2C);
    void vEcrirePcf(unsigned char ucDataPcf);
    unsigned char ucLecturePcf(void);
    void vEtatDetecteurDeLigne(unsigned char ucEtatDetecteur);
private:
   unsigned char adresseI2C;
};

#endif
 
